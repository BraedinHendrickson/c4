#ifndef file_utils_h_
#define file_utils_h_

int read_file( char* filename, char **buffer );

int write_file( char* filename, char *buffer, int size);

#endif